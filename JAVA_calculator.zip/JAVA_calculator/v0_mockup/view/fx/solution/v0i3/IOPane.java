package view.fx.solution.v0i3;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class IOPane extends VBox {

    private final ModePane modePane;
    private final TextField input;
    private final Label output;

    public IOPane(ModePane modePane) {
        this.modePane = modePane;
        this.input = new TextField();
        this.output = new Label();

        setSpacing(MockUp3.SMALL);
        setPadding(new Insets(MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM));
        getChildren().addAll(modePane, input, output);
    }

    public ModePane getModePane() {
        return modePane;
    }

    public TextField getInput() {
        return input;
    }

    public Label getOutput() {
        return output;
    }
}
