package view.fx.solution.v0i3;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class ControlPane extends VBox {

    private final Button equalButton;
    private final Button clearButton;
    private final Button undoButton;
    private final Button redoButton;
    private final Button saveButton;

    public ControlPane() {
        this.equalButton =  new FixedSizeButton("=");
        this.clearButton = new FixedSizeButton("C");
        this.undoButton = new FixedSizeButton("<<");
        this.redoButton = new FixedSizeButton(">>");
        this.saveButton = new FixedSizeButton("M+");

        setPadding(new Insets(MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM));
        getChildren().addAll(equalButton, clearButton, undoButton, redoButton, saveButton);
    }

    public Button getEqualButton() {
        return equalButton;
    }

    public Button getClearButton() {
        return clearButton;
    }

    public Button getUndoButton() {
        return undoButton;
    }

    public Button getRedoButton() {
        return redoButton;
    }

    public Button getSaveButton() {
        return saveButton;
    }
}
