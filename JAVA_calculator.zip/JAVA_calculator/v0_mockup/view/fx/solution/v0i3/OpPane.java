package view.fx.solution.v0i3;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import model.ArithmeticOperator;

public class OpPane extends VBox {

    private final Button[] opButtons;

    protected OpPane() {
        ArithmeticOperator[] operators = ArithmeticOperator.values();

        opButtons = new Button[operators.length];
        for (int i = 0; i < operators.length; i++) {
            opButtons[i] = new FixedSizeButton(operators[i].getSymbol());
        }

        setPadding(new Insets(MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM, MockUp3.MEDIUM));
        getChildren().addAll(opButtons);
    }

    public Button[] getOpButtons() {
        return opButtons;
    }

}
