package view.fx.solution.v0i3;

import javafx.geometry.Insets;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;

public class ModePane extends HBox {

    private final RadioButton infixButton;
    private final RadioButton rpnButton;

    public ModePane() {
        this.infixButton = new RadioButton("Infix");
        this.rpnButton = new RadioButton("RPN");

        ToggleGroup modeButtonGroup = new ToggleGroup();
        infixButton.setToggleGroup(modeButtonGroup);
        rpnButton.setToggleGroup(modeButtonGroup);

        infixButton.setSelected(true);

        setPadding(new Insets(10,10,10,10));
        getChildren().addAll(infixButton,rpnButton);
    }

    public RadioButton getInfixButton() {
        return infixButton;
    }

    public RadioButton getRpnButton() {
        return rpnButton;
    }

}
