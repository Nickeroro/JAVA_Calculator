package view.fx.solution.v0i3;

import javafx.scene.control.Button;

public class FixedSizeButton extends Button {

    public FixedSizeButton(String text) {
        super(text);

        setPrefSize(50, 50);
    }

}
