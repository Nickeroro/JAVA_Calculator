package view.fx.solution.v0i2;

import model.ArithmeticOperator;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

@SuppressWarnings("ALL")
public class MockUp2 extends Application {

    static private final int SMALL = 5;

    static private final int LARGE = 20;

    static private final int[] REGISTER_VALUES = {8, 11};

    private HBox createModePane() {
        ToggleGroup modeButtonGroup = new ToggleGroup();
        RadioButton infixButton = new RadioButton("Infix");
        infixButton.setToggleGroup(modeButtonGroup);
        RadioButton rpnButton = new RadioButton("RPN");
        rpnButton.setToggleGroup(modeButtonGroup);
        infixButton.setSelected(true);

        HBox modePane = new HBox();
        modePane.setSpacing(LARGE);
        modePane.getChildren().addAll(infixButton, rpnButton);

        return modePane;
    }

    private VBox createIOPane() {
        HBox modePane = createModePane();
        TextField input = new TextField("3 + 2");
        Label output = new Label("5");

        VBox ioPane = new VBox();
        ioPane.setSpacing(SMALL);
        ioPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        ioPane.getChildren().addAll(modePane, input, output);

        return ioPane;
    }



    private GridPane createNumPane() {
        Button[] digitButtons = new Button[10];
        for (int i = 0; i < 10; i++) {
            digitButtons[i] = createButton(Integer.toString(i));
        }

        Button spaceButton = createButton("_");
        Button deleteButton = createButton("Del");

        GridPane numPane = new GridPane();
        numPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        numPane.addRow(0, digitButtons[7], digitButtons[8], digitButtons[9]);
        numPane.addRow(1, digitButtons[4], digitButtons[5], digitButtons[6]);
        numPane.addRow(2, digitButtons[1], digitButtons[2], digitButtons[3]);
        numPane.addRow(3, digitButtons[0], spaceButton, deleteButton);

        return numPane;
    }

    private VBox createOpPane() {
        ArithmeticOperator[] operators = ArithmeticOperator.values();

        Button[] opButtons = new Button[operators.length];
        for (int i = 0; i < operators.length; i++) {
            opButtons[i] = createButton(operators[i].getSymbol());
        }

        VBox opPane = new VBox();
        opPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        opPane.getChildren().addAll(opButtons);

        return opPane;
    }

    static private final int MEDIUM = 10;

    private Button createButton(String text) {
        Button button = new Button(text);
        button.setPrefSize(50, 50);
        return button;
    }

    private VBox createControlPane() {
        Button equalButton = createButton("=");
        Button clearButton = createButton("C");
        Button undoButton = createButton("<<");
        Button redoButton = createButton(">>");
        Button saveButton = createButton("M+");

        VBox controlPane = new VBox();
        controlPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        controlPane.getChildren().addAll(equalButton, clearButton, undoButton, redoButton, saveButton);

        return controlPane;
    }

    private HBox createRegister(int value) {
        Button loadButton = createButton("M-");
        Label label = new Label(Integer.toString(value));

        HBox register = new HBox();
        register.setSpacing(SMALL);
        register.getChildren().addAll(loadButton, label);

        return register;
    }

    private VBox createRegisterPane() {
        VBox registerPane = new VBox();
        registerPane.setSpacing(SMALL);
        registerPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));

        for (int value : REGISTER_VALUES) {
            registerPane.getChildren().add(createRegister(value));
        }

        return registerPane;
    }

    private HBox createBottomPane() {
        HBox bottomPane = new HBox();
        bottomPane.getChildren().addAll(
                createNumPane(),
                createOpPane(),
                createControlPane(),
                createRegisterPane()
        );
        return bottomPane;
    }

    private Pane createRootPane() {
        VBox rootPane = new VBox();
        rootPane.getChildren().addAll(createIOPane(), createBottomPane());
        return rootPane;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(createRootPane(), 450, 375);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Calculator MockUp 2");
        primaryStage.setResizable(false);
        primaryStage.show();
    }

}
