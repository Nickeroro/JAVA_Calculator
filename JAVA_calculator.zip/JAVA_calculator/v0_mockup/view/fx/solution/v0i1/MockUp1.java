package view.fx.solution.v0i1;

import model.ArithmeticOperator;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MockUp1 extends Application {

    static private final int SMALL = 5;
    static private final int MEDIUM = 10;
    static private final int LARGE = 20;

    public Pane createRootPane() {
        // Create graphical end nodes

        ToggleGroup modeButtonGroup = new ToggleGroup();
        RadioButton infixButton = new RadioButton("Infix");
        infixButton.setToggleGroup(modeButtonGroup);
        RadioButton rpnButton = new RadioButton("RPN");
        rpnButton.setToggleGroup(modeButtonGroup);
        infixButton.setSelected(true);

        TextField input = new TextField("3 + 2");
        Label output = new Label("5");

        Button[] digitButtons = new Button[10];
        for (int i = 0; i < 10; i++) {
            digitButtons[i] = new Button(Integer.toString(i));
        }

        Button spaceButton = new Button("_");
        Button deleteButton = new Button("Del");

        ArithmeticOperator[] operators = ArithmeticOperator.values();

        Button[] opButtons = new Button[operators.length];
        for (int i = 0; i < operators.length; i++) {
            opButtons[i] = new Button(operators[i].getSymbol());
        }

        Button equalButton = new Button("=");
        Button clearButton = new Button("C");
        Button undoButton = new Button("<<");
        Button redoButton = new Button(">>");
        Button saveButton = new Button("M+");

        Label registerLabel1 = new Label("8");
        Button loadButton1 = new Button("M-");
        Label registerLabel2 = new Label("11");
        Button loadButton2 = new Button("M-");


        // Create basic panes

        HBox modePane = new HBox();
        modePane.setSpacing(LARGE);
        modePane.getChildren().addAll(infixButton, rpnButton);

        VBox ioPane = new VBox();
        ioPane.setSpacing(SMALL);
        ioPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        ioPane.getChildren().addAll(modePane, input, output);

        GridPane numPane = new GridPane();
        numPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        numPane.addRow(0, digitButtons[7], digitButtons[8], digitButtons[9]);
        numPane.addRow(1, digitButtons[4], digitButtons[5], digitButtons[6]);
        numPane.addRow(2, digitButtons[1], digitButtons[2], digitButtons[3]);
        numPane.addRow(3, digitButtons[0], spaceButton, deleteButton);

        VBox opPane = new VBox();
        opPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        opPane.getChildren().addAll(opButtons);

        VBox controlPane = new VBox();
        controlPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        controlPane.getChildren().addAll(equalButton, clearButton, undoButton, redoButton, saveButton);

        HBox registerPane1 = new HBox();
        registerPane1.setSpacing(SMALL);
        registerPane1.getChildren().addAll(loadButton1, registerLabel1);

        HBox registerPane2 = new HBox();
        registerPane2.setSpacing(SMALL);
        registerPane2.getChildren().addAll(loadButton2, registerLabel2);

        VBox allRegistersPane = new VBox();
        allRegistersPane.setSpacing(SMALL);
        allRegistersPane.setPadding(new Insets(MEDIUM, MEDIUM, MEDIUM, MEDIUM));
        allRegistersPane.getChildren().addAll(registerPane1, registerPane2);

        HBox bottomPane = new HBox();
        bottomPane.getChildren().addAll(numPane, opPane, controlPane, allRegistersPane);


        // root pane

        VBox rootPane = new VBox();
        rootPane.getChildren().addAll(ioPane, bottomPane);

        return rootPane;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(createRootPane(), 300, 250);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Calculator MockUp 1");
        primaryStage.setResizable(false);
        primaryStage.show();
    }

}
