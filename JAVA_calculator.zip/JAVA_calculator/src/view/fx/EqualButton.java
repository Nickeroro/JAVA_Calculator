package view.fx;

import control.ExpressionProcessor;
import control.InfixExpressionProcessor;
import control.RPNExpressionProcessor;
import javafx.event.ActionEvent;

public class EqualButton extends FixedSizeButton {


    public EqualButton(String text) {
        super(text);
        setOnAction(this::computeResult);
    }

    protected ExpressionProcessor processor;

    private void computeResult(ActionEvent ignored) {
        //this.processor = new RPNExpressionProcessor();

        //String value = ((Button) event.getSource()).getText();
        //System.out.println(value);
        if (ModePane.infixButton.isSelected() == true){
            this.processor = new InfixExpressionProcessor();

            try {
                this.processor.processExpression(IOPane.input.getText());
                IOPane.output.setText(String.valueOf(this.processor.getResult()));

            } catch (Exception e) {
                IOPane.output.setText("Oops!");
                e.printStackTrace();
            }

        }
        else if (ModePane.rpnButton.isSelected() == true){
            this.processor = new RPNExpressionProcessor();

            try {
                this.processor.processExpression(IOPane.input.getText());
                IOPane.output.setText(String.valueOf(this.processor.getResult()));

            } catch (Exception e) {
                IOPane.output.setText("Oops!");
                e.printStackTrace();
            }


        }

    }
}
