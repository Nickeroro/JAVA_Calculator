package view.fx;

import control.ExpressionProcessor;
import control.InfixExpressionProcessor;
import control.RPNExpressionProcessor;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;

public class ModePane extends HBox {

    protected ExpressionProcessor processor;

    public static RadioButton infixButton;
    public static RadioButton rpnButton;



    public ModePane() {
        this.infixButton = new RadioButton("Infix");
        //infixButton.setOnAction(this::modSwitch);
        this.rpnButton = new RadioButton("RPN");
        //rpnButton.setOnAction(this::modSwitch);

        ToggleGroup modeButtonGroup = new ToggleGroup();
        infixButton.setToggleGroup(modeButtonGroup);
        rpnButton.setToggleGroup(modeButtonGroup);

        infixButton.setSelected(true);




        setPadding(new Insets(10,10,10,10));
        getChildren().addAll(infixButton,rpnButton);
    }

    /*private void modSwitch(ActionEvent actionEvent) {
        if(infixButton.isSelected() == true){
            this.processor = new InfixExpressionProcessor();
        }else if(rpnButton.isSelected() == true){
            this.processor = new RPNExpressionProcessor();
        }
    }*/

    public RadioButton getInfixButton() {
        return infixButton;
    }

    public RadioButton getRpnButton() {
        return rpnButton;
    }

}